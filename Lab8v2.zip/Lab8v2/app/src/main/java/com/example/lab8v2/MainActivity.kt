package com.example.lab8v2

import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //variables
        val dept: Spinner = findViewById(R.id.dept)
        val dept_array =  resources.getStringArray(R.array.dept_array)

        if (dept != null) {
            val adapter = ArrayAdapter ( this,
                android.R.layout.simple_spinner_item, dept_array)
            dept.adapter = adapter
            dept.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?,
                                            view: View?, position: Int, id: Long) {
                    Toast.makeText( this@MainActivity,
                        "Selected Item" + " " +
                                "" + dept_array[position], Toast.LENGTH_SHORT).show()
                }
                override fun onNothingSelected(parent: AdapterView<*>?) {

                }
           }
        }
    }
}