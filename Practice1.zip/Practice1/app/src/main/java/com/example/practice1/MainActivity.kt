package com.example.practice1


import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private lateinit var nameInput: EditText
    private lateinit var ageInput: EditText
    private lateinit var sessionGroup: RadioGroup
    private lateinit var displayButton: Button
    private lateinit var resultDisplay: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "Consultant App - [Your Name with Register Number]"


        // Initialize UI elements
        nameInput = findViewById(R.id.nameInput)
        ageInput = findViewById(R.id.ageInput)
        sessionGroup = findViewById(R.id.sessionGroup)
        displayButton = findViewById(R.id.displayButton)
        resultDisplay = findViewById(R.id.resultDisplay)

        displayButton.setOnClickListener { displayConsultant() }
    }

    @SuppressLint("SetTextI18n")
    private fun displayConsultant() {
        val name = nameInput.text.toString()
        val age = ageInput.text.toString().toInt()
        val selectedSessionId = sessionGroup.checkedRadioButtonId
        val selectedSession = findViewById<RadioButton>(selectedSessionId)
        val session = selectedSession.text.toString()

        val consultant = if (age < 12) {
            if (session == "S1") "Dr. William" else "Dr. Francis"
        } else {
            if (session == "S1") "Dr. Silva" else "Dr. Kate"
        }

        resultDisplay.text = "Consultant for $name: $consultant"
    }
}