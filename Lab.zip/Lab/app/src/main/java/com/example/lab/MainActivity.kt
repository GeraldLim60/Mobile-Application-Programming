package com.example.lab

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity: AppCompatActivity() {

// insert variable declaration here
    lateinit var editText_number1: EditText
    lateinit var editText_number2: EditText
    lateinit var button_add: Button
    lateinit var textView_result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

//find the components from XML. Case sensitive
//<variables> = findViewById(R.id.<id of component from XML>)
        editText_number1 = findViewById(R.id.editText_number1)
        editText_number2 = findViewById(R.id.editText_number2)
        button_add = findViewById(R.id.button_add)
        textView_result = findViewById(R.id.textView_result)

        button_add.setOnClickListener {
            val num1 = editText_number1.text.toString().toInt()
            val num2 =  editText_number2.text.toString().toInt()
            val res = num1 + num2
            textView_result.text = res.toString()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}